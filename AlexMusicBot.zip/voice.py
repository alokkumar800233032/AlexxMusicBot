
"""
Voice-chat layer.

The project keeps this isolated because pytgcalls APIs differ between releases.
It uses a small adapter so the rest of the bot remains unchanged.

If your installed pytgcalls release exposes a different MediaStream/AudioPiped
API, update ONLY this file according to that release's documentation.
"""
import asyncio
from config import API_ID, API_HASH, SESSION_STRING
from music import stream_url

class VoiceManager:
    def __init__(self):
        self.client = None
        self.calls = None
        self.ready = False

    async def start(self):
        if API_ID == "alok" or API_HASH == "alok" or SESSION_STRING == "alok":
            print("Assistant credentials are still 'alok'; voice playback is disabled until configured.")
            return False
        try:
            from pyrogram import Client
            from pytgcalls import PyTgCalls
            self.client = Client(
                "alex_assistant",
                api_id=int(API_ID),
                api_hash=API_HASH,
                session_string=SESSION_STRING
            )
            await self.client.start()
            self.calls = PyTgCalls(self.client)
            await self.calls.start()
            self.ready = True
            return True
        except Exception as e:
            print("Voice startup error:", repr(e))
            return False

    async def play(self, chat_id, youtube_url):
        if not self.ready:
            raise RuntimeError("Assistant account configured nahi hai.")
        audio_url, info = await asyncio.to_thread(stream_url, youtube_url)
        # Compatibility adapter for common pytgcalls 2.x interfaces.
        try:
            from pytgcalls.types import AudioPiped
        except ImportError:
            from pytgcalls.types.input_stream import AudioPiped
        source = AudioPiped(audio_url)
        try:
            await self.calls.join_group_call(chat_id, source)
        except Exception:
            await self.calls.change_stream(chat_id, source)
        return info

    async def stop(self, chat_id):
        if self.ready:
            try:
                await self.calls.leave_group_call(chat_id)
            except Exception:
                pass

voice = VoiceManager()
