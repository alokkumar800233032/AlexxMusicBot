
# ============================================================
# ALEX MUSIC - SIRF "alok" KO APNI VALUE SE REPLACE KARNA HAI
# ============================================================

BOT_TOKEN = "alok"
OWNER_ID = 8722836338

# Assistant/user account for voice-chat playback
API_ID = "36021063"
API_HASH = "7801fe06e03890d8a922e769d56c3914"
SESSION_STRING = "BQIlo0cAAnaeujkdDG2PP4gUpmujFJMRuz5FY_no98dkEaQAJWn8EZt3Ulu8VhPoX6PJWNbUwjcVvWBz5blhAW674-8v_hJOQVyY3kijvF8kyByn8zYFU0cVbqCRa8b2mHopQSrxShTrpIlwzl_mz7Cizyt7jYjCXi9V2ndS9N9dVhtFWAtSETbxi8JzDm8bnMUJ-e0sJLNc4d_vKLI07RbTq4TKCQa9MiooEsax_At-D9b7PiqNB__dPlQjmbpxP7bBvSvUdounMZxIlVxDtCqLV5iGSsZ6mgB2LeTD-HEUmQY4rol1IEATW6tqOQn_tDRTNKRO2v_0iNxhxTWkSrVIVoD2OwAAAAIH6-tyAA"

# Optional: public bot username (without @)
BOT_USERNAME = "AlexMusicXBot"
BOT_NAME = "Alex Music"

# Limits / defaults
MAX_QUEUE = 50
DEFAULT_VOLUME = 100
AUTO_LEAVE_SECONDS = 120

# Optional MongoDB is NOT required. This starter uses SQLite.
# Render persistent disk is recommended if you want stats/settings
# to survive redeploys.
