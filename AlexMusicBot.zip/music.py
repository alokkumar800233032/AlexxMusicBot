
import asyncio
import os
import re
import yt_dlp
from collections import defaultdict, deque

queues = defaultdict(deque)
current = {}
volume = defaultdict(lambda: 100)
loop_mode = defaultdict(lambda: 0)  # 0 off, 1 track, 2 queue
players = {}

YTDLP_OPTS = {
    "quiet": True,
    "no_warnings": True,
    "format": "bestaudio/best",
    "noplaylist": True,
    "extract_flat": False,
}

def search_youtube(query, limit=5):
    with yt_dlp.YoutubeDL({**YTDLP_OPTS, "extract_flat": True}) as ydl:
        data = ydl.extract_info(f"ytsearch{limit}:{query}", download=False)
    return [{
        "title": x.get("title","Unknown"),
        "url": x.get("webpage_url") or x.get("url"),
        "duration": x.get("duration") or 0,
        "id": x.get("id","")
    } for x in (data.get("entries") or [])]

def stream_url(url):
    with yt_dlp.YoutubeDL(YTDLP_OPTS) as ydl:
        info = ydl.extract_info(url, download=False)
        return info.get("url"), info

async def add(chat_id, track):
    queues[chat_id].append(track)

async def pop(chat_id):
    if queues[chat_id]:
        return queues[chat_id].popleft()
    return None

def clear(chat_id):
    queues[chat_id].clear()

def queue_list(chat_id):
    return list(queues[chat_id])

def format_duration(sec):
    if not sec: return "LIVE"
    sec = int(sec)
    return f"{sec//60}:{sec%60:02d}"
