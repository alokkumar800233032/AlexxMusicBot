
# 🎵 Alex Music Bot

Telegram group music bot project.

## Your fixed details
- Name: Alex Music
- Username: @AlexMusicXBot
- Owner ID: 8722836338
- Music source: YouTube

## IMPORTANT: "alok" replacement

Open `config.py`.

Every place containing `alok` is a value you need to replace:

```text
BOT_TOKEN = "alok"          -> BotFather token
API_ID = "alok"             -> Assistant account API ID
API_HASH = "alok"           -> Assistant account API Hash
SESSION_STRING = "alok"     -> Assistant account session string
```

Do NOT replace the `OWNER_ID` unless you want a different owner.

Do NOT send your OTP, 2FA password, or session string to anyone.

## Assistant account

A normal Telegram account is used for voice-chat playback.

1. Create/get API ID and API Hash at https://my.telegram.org
2. Generate a Pyrogram session string yourself.
3. Put those three values in `config.py` or, preferably, Render environment variables.

## Local test

```bash
pip install -r requirements.txt
python main.py
```

## Render

1. Create a Render Background Worker.
2. Upload this ZIP to GitHub or your preferred repository.
3. Build command:
   `pip install -r requirements.txt`
4. Start command:
   `python main.py`
5. Set the four `alok` credentials as Environment Variables / update config.py.

Recommended environment names:
BOT_TOKEN
API_ID
API_HASH
SESSION_STRING
OWNER_ID

The included config.py is intentionally simple so you can replace `alok`.

## Admin panel

`/admin` is Owner-only.

Included areas:
- Statistics
- User management
- Group management
- Broadcast
- Block/unblock
- Logs
- Global settings
- Music settings
- Render restart information

## Group music

Only group admins can use:
- /play
- /skip
- /stop
- /leave
- /clear
- /queue
- /nowplaying
- /pause
- /resume

## Telegram bot settings

In BotFather:
- Enable Group Privacy OFF if you want the bot to see normal group messages.
- Add the bot to the target group.
- Make the bot an admin with permission to manage voice chats as needed.

## Voice chat note

Telegram voice-chat streaming libraries can change their APIs. `voice.py` isolates that integration. If a pytgcalls release changes its method names, only `voice.py` needs adjustment.

## Security

Never publish:
- Bot token
- API hash
- Assistant session string
- OTP / 2FA password

Use Render Environment Variables for production.
