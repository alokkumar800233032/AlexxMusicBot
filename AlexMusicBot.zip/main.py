
import asyncio
import logging
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from config import BOT_TOKEN, OWNER_ID
from db import init_db
from handlers import register_handlers

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("alexmusic")

async def main():
    if BOT_TOKEN == "alok":
        raise RuntimeError("BOT_TOKEN abhi 'alok' hai. config.py me ise apne BotFather token se replace karo.")
    await init_db()
    bot = Bot(BOT_TOKEN, default=DefaultBotProperties(parse_mode=ParseMode.HTML))
    dp = Dispatcher()
    register_handlers(dp)
    log.info("Alex Music starting...")
    await dp.start_polling(bot)

if __name__ == "__main__":
    asyncio.run(main())
