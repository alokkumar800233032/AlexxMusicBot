
import asyncio
from aiogram import F
from aiogram import types, Dispatcher
from aiogram.filters import Command
from aiogram.utils.keyboard import InlineKeyboardBuilder
from config import OWNER_ID, BOT_NAME, BOT_USERNAME, MAX_QUEUE
from db import upsert_user, upsert_chat, is_blocked, stats, set_block, log_action
from music import search_youtube, add, pop, queue_list, clear, format_duration
from voice import voice

pending = {}

def is_owner(user_id): return user_id == OWNER_ID

async def is_group_admin(bot, chat_id, user_id):
    if user_id == OWNER_ID: return True
    try:
        member = await bot.get_chat_member(chat_id, user_id)
        return member.status in ("administrator", "creator")
    except Exception:
        return False

async def allowed(message):
    return not await is_blocked(message.from_user.id)

def admin_panel():
    kb = InlineKeyboardBuilder()
    buttons = [
        ("📊 Statistics","stats"), ("👥 Users","users"),
        ("🏠 Groups","groups"), ("📢 Broadcast","broadcast"),
        ("🚫 Block User","block"), ("✅ Unblock User","unblock"),
        ("📋 Logs","logs"), ("⚙️ Settings","settings"),
        ("🎵 Music Settings","music_settings"), ("🔄 Restart Info","restart"),
    ]
    for text, data in buttons:
        kb.button(text=text, callback_data=f"admin:{data}")
    kb.adjust(2)
    return kb.as_markup()

def search_keyboard(results):
    kb = InlineKeyboardBuilder()
    for i, r in enumerate(results):
        title = r["title"][:45]
        kb.button(text=f"🎵 {i+1}. {title}", callback_data=f"pick:{i}")
    kb.adjust(1)
    return kb.as_markup()

async def play_next(bot, chat_id):
    track = await pop(chat_id)
    if not track:
        await voice.stop(chat_id)
        return
    try:
        await voice.play(chat_id, track["url"])
        await bot.send_message(
            chat_id,
            f"▶️ <b>Now Playing</b>\n{track['title']}\n⏱ {format_duration(track['duration'])}"
        )
    except Exception as e:
        await bot.send_message(chat_id, f"❌ Playback error: <code>{str(e)[:500]}</code>")

def register_handlers(dp: Dispatcher):
    @dp.message(Command("start"))
    async def start(m: types.Message):
        await upsert_user(m.from_user)
        if m.chat.type in ("group","supergroup"):
            await upsert_chat(m.chat.id, m.chat.title)
        if not await allowed(m):
            return
        await m.answer(
            f"🎵 <b>{BOT_NAME}</b>\n\n"
            "YouTube se music search/play karne ke liye:\n"
            "<code>/play song name</code>\n\n"
            "Admin: <code>/admin</code>\n"
            "Help: <code>/help</code>"
        )

    @dp.message(Command("help"))
    async def help_cmd(m):
        await m.answer(
            "<b>🎵 Alex Music Commands</b>\n\n"
            "<b>Music</b>\n"
            "/play &lt;song&gt; — search/play\n"
            "/skip — next song\n"
            "/pause — pause (player dependent)\n"
            "/resume — resume\n"
            "/stop — stop & leave\n"
            "/queue — queue\n"
            "/nowplaying — current track\n"
            "/clear — clear queue\n"
            "/leave — leave voice chat\n\n"
            "<b>Group Admin</b>\n"
            "/dj — DJ controls\n"
            "/settings — group settings\n\n"
            "<b>Owner</b>\n"
            "/admin — admin panel"
        )

    @dp.message(Command("admin"))
    async def admin(m):
        if not is_owner(m.from_user.id):
            return await m.answer("⛔ Owner only.")
        await m.answer("🛠️ <b>Alex Music Admin Panel</b>", reply_markup=admin_panel())

    @dp.callback_query(F.data.startswith("admin:"))
    async def admin_callbacks(c: types.CallbackQuery, bot):
        if not is_owner(c.from_user.id):
            return await c.answer("Owner only", show_alert=True)
        action = c.data.split(":",1)[1]
        if action == "stats":
            s = await stats()
            text = f"📊 <b>Statistics</b>\nUsers: {s['users']}\nGroups: {s['groups']}\nAdmins: {s['admins']}\nLogs: {s['logs']}"
        elif action == "broadcast":
            text = "📢 Broadcast: /broadcast your message"
        elif action == "block":
            text = "🚫 Use /block USER_ID"
        elif action == "unblock":
            text = "✅ Use /unblock USER_ID"
        elif action == "users":
            text = "👥 User management: /block, /unblock"
        elif action == "groups":
            text = "🏠 Group management is stored in SQLite."
        elif action == "logs":
            text = "📋 Logs are stored in alexmusic.db."
        elif action == "settings":
            text = "⚙️ Global settings are in config.py."
        elif action == "music_settings":
            text = "🎵 YouTube + queue + voice-chat playback settings."
        else:
            text = "🔄 Render restart: use the Render dashboard."
        await c.message.edit_text(text, reply_markup=admin_panel())
        await c.answer()

    @dp.message(Command("broadcast"))
    async def broadcast(m, bot):
        if not is_owner(m.from_user.id): return
        msg = m.text.partition(" ")[2].strip()
        if not msg: return await m.answer("Usage: /broadcast message")
        # Safe/simple implementation: only sends to chats recorded in DB in production.
        import aiosqlite
        from db import DB
        async with aiosqlite.connect(DB) as db:
            cur = await db.execute("SELECT chat_id FROM chats")
            chats = [x[0] for x in await cur.fetchall()]
        sent = 0
        for cid in chats:
            try:
                await bot.send_message(cid, msg)
                sent += 1
            except: pass
        await m.answer(f"📢 Broadcast finished. Sent: {sent}")

    @dp.message(Command("block"))
    async def block(m):
        if not is_owner(m.from_user.id): return
        try: uid = int(m.text.split()[1])
        except: return await m.answer("Usage: /block USER_ID")
        await set_block(uid, True); await m.answer(f"🚫 Blocked <code>{uid}</code>")

    @dp.message(Command("unblock"))
    async def unblock(m):
        if not is_owner(m.from_user.id): return
        try: uid = int(m.text.split()[1])
        except: return await m.answer("Usage: /unblock USER_ID")
        await set_block(uid, False); await m.answer(f"✅ Unblocked <code>{uid}</code>")

    @dp.message(Command("play"))
    async def play(m, bot):
        if not await allowed(m): return
        if m.chat.type not in ("group","supergroup"):
            return await m.answer("❌ Music commands group me use karo.")
        if not await is_group_admin(bot, m.chat.id, m.from_user.id):
            return await m.answer("⛔ Sirf group admins music chala sakte hain.")
        query = m.text.partition(" ")[2].strip()
        if not query: return await m.answer("Usage: /play song name")
        await upsert_chat(m.chat.id, m.chat.title)
        await m.answer("🔎 YouTube par search ho raha hai...")
        try:
            results = await asyncio.to_thread(search_youtube, query, 5)
        except Exception as e:
            return await m.answer(f"❌ Search error: {str(e)[:500]}")
        if not results: return await m.answer("❌ Song nahi mila.")
        pending[m.from_user.id] = results
        await m.answer("🎵 <b>Song select karo:</b>", reply_markup=search_keyboard(results))

    @dp.callback_query(F.data.startswith("pick:"))
    async def pick(c, bot):
        results = pending.get(c.from_user.id, [])
        try: idx = int(c.data.split(":")[1])
        except: return await c.answer("Invalid")
        if idx >= len(results): return await c.answer("Search expired", show_alert=True)
        if not await is_group_admin(bot, c.message.chat.id, c.from_user.id):
            return await c.answer("Admins only", show_alert=True)
        track = results[idx]
        q = queue_list(c.message.chat.id)
        if len(q) >= MAX_QUEUE:
            return await c.answer("Queue full", show_alert=True)
        was_empty = len(q) == 0
        await add(c.message.chat.id, track)
        await c.message.edit_text(f"✅ Added to queue:\n<b>{track['title']}</b>")
        await c.answer()
        if was_empty:
            await play_next(bot, c.message.chat.id)

    @dp.message(Command("skip"))
    async def skip(m, bot):
        if not await is_group_admin(bot, m.chat.id, m.from_user.id): return
        await voice.stop(m.chat.id)
        await play_next(bot, m.chat.id)

    @dp.message(Command("stop","leave"))
    async def stop(m, bot):
        if not await is_group_admin(bot, m.chat.id, m.from_user.id): return
        clear(m.chat.id)
        await voice.stop(m.chat.id)
        await m.answer("⏹️ Music stopped.")

    @dp.message(Command("clear"))
    async def clear_cmd(m):
        if not await is_group_admin(m.bot, m.chat.id, m.from_user.id): return
        clear(m.chat.id); await m.answer("🗑️ Queue cleared.")

    @dp.message(Command("queue"))
    async def queue_cmd(m):
        q = queue_list(m.chat.id)
        if not q: return await m.answer("📭 Queue empty.")
        lines = ["🎵 <b>Queue</b>"]
        for i, x in enumerate(q[:20], 1):
            lines.append(f"{i}. {x['title'][:70]}")
        await m.answer("\n".join(lines))

    @dp.message(Command("nowplaying"))
    async def now(m):
        from music import current
        t = current.get(m.chat.id)
        await m.answer(f"🎧 {t['title']}" if t else "Nothing is playing.")

    @dp.message(Command("pause"))
    async def pause(m):
        if not await is_group_admin(m.bot, m.chat.id, m.from_user.id): return
        try:
            await voice.calls.pause_stream(m.chat.id)
            await m.answer("⏸️ Paused.")
        except Exception:
            await m.answer("⚠️ Pause API is not available in the installed pytgcalls version.")

    @dp.message(Command("resume"))
    async def resume(m):
        if not await is_group_admin(m.bot, m.chat.id, m.from_user.id): return
        try:
            await voice.calls.resume_stream(m.chat.id)
            await m.answer("▶️ Resumed.")
        except Exception:
            await m.answer("⚠️ Resume API is not available in the installed pytgcalls version.")
