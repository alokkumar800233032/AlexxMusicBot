
import aiosqlite
from pathlib import Path

DB = Path("alexmusic.db")

async def init_db():
    async with aiosqlite.connect(DB) as db:
        await db.executescript("""
        CREATE TABLE IF NOT EXISTS users(
            user_id INTEGER PRIMARY KEY,
            name TEXT,
            username TEXT,
            blocked INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS chats(
            chat_id INTEGER PRIMARY KEY,
            title TEXT,
            enabled INTEGER DEFAULT 1,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        CREATE TABLE IF NOT EXISTS admins(
            user_id INTEGER PRIMARY KEY,
            role TEXT DEFAULT 'admin'
        );
        CREATE TABLE IF NOT EXISTS settings(
            chat_id INTEGER PRIMARY KEY,
            volume INTEGER DEFAULT 100,
            dj_mode INTEGER DEFAULT 0,
            autoplay INTEGER DEFAULT 0,
            max_queue INTEGER DEFAULT 50,
            loop_mode INTEGER DEFAULT 0
        );
        CREATE TABLE IF NOT EXISTS logs(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            chat_id INTEGER,
            action TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        );
        """)
        await db.commit()

async def upsert_user(user):
    async with aiosqlite.connect(DB) as db:
        await db.execute(
            "INSERT INTO users(user_id,name,username) VALUES(?,?,?) "
            "ON CONFLICT(user_id) DO UPDATE SET name=excluded.name, username=excluded.username",
            (user.id, user.full_name, user.username or "")
        )
        await db.commit()

async def upsert_chat(chat_id, title):
    async with aiosqlite.connect(DB) as db:
        await db.execute(
            "INSERT INTO chats(chat_id,title) VALUES(?,?) "
            "ON CONFLICT(chat_id) DO UPDATE SET title=excluded.title",
            (chat_id, title or "")
        )
        await db.execute(
            "INSERT OR IGNORE INTO settings(chat_id) VALUES(?)", (chat_id,)
        )
        await db.commit()

async def log_action(user_id, chat_id, action):
    async with aiosqlite.connect(DB) as db:
        await db.execute("INSERT INTO logs(user_id,chat_id,action) VALUES(?,?,?)",
                         (user_id, chat_id, action))
        await db.commit()

async def is_blocked(user_id):
    async with aiosqlite.connect(DB) as db:
        cur = await db.execute("SELECT blocked FROM users WHERE user_id=?", (user_id,))
        row = await cur.fetchone()
        return bool(row and row[0])

async def set_block(user_id, value):
    async with aiosqlite.connect(DB) as db:
        await db.execute("UPDATE users SET blocked=? WHERE user_id=?", (int(value), user_id))
        await db.commit()

async def stats():
    async with aiosqlite.connect(DB) as db:
        out = {}
        for key, table in [("users","users"),("groups","chats"),("admins","admins"),("logs","logs")]:
            cur = await db.execute(f"SELECT COUNT(*) FROM {table}")
            out[key] = (await cur.fetchone())[0]
        return out
